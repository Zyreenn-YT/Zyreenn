// DATA EFOOTBALL
const eFootballData = [
    {
        kategori: "eFootball Patch",
        judul: "eFootball 2026 License & Kit Patch v1.0",
        deskripsi: "Membuka seluruh lisensi klub, Jersey original 2026, dan logo liga resmi.",
        linkDownload: "#"
    },
    {
        kategori: "Config eFootball",
        judul: "Config Ultra Smooth 60 FPS (Anti-Lag)",
        deskripsi: "Optimasi grafik untuk HP spesifikasi menengah ke bawah agar lancar tanpa lag.",
        linkDownload: "#"
    },
    {
        kategori: "Aplikasi Pendukung",
        judul: "eFootball Graphics Switcher Tool",
        deskripsi: "Aplikasi penyesuai resolusi dan rasio layar eFootball dengan 1-klik.",
        linkDownload: "#"
    },
    {
        kategori: "Config eFootball",
        judul: "Unlock Max Graphics & High FPS",
        deskripsi: "Membuka grafik tertinggi dan bayangan realistis untuk perangkat flagship.",
        linkDownload: "#"
    }
];

// DATA GAME & APLIKASI LAINNYA
const otherGamesData = [
    {
        kategori: "Game Android",
        judul: "Game Booster Pro ZYREENN Edition",
        deskripsi: "Aplikasi pembersih RAM dan penstabil jaringan ping saat bermain game online.",
        linkDownload: "#"
    },
    {
        kategori: "Game PC",
        judul: "Custom Resolution Utility (CRU)",
        deskripsi: "Aplikasi pendukung untuk custom refresh rate monitor gaming.",
        linkDownload: "#"
    },
    {
        kategori: "Emulator",
        judul: "PPSSPP Gold Mod ZYREENN Theme",
        deskripsi: "Emulator PSP dengan tema kostum Merah ZYREENN & settingan lancar.",
        linkDownload: "#"
    }
];

// DATA CHANGELOG (16:9 ASPECT RATIO)
const changelogData = [
    {
        versi: "v1.3",
        tanggal: "20 Okt 2026",
        tipe: "Update Fitur",
        gambar: "assets/images/banner.png",
        linkDetail: "cek-kompatibilitas.html",
        rincian: [
            "Rilis halaman Cek Kompatibilitas HP interaktif.",
            "Penambahan LATEST CONTENT dengan format kartu VT 9:16."
        ]
    },
    {
        versi: "v1.2",
        tanggal: "18 Okt 2026",
        tipe: "Update Halaman",
        gambar: "assets/images/banner.png",
        linkDetail: "efootball-patch.html",
        rincian: [
            "Peluncuran halaman khusus eFootball Patch Hub.",
            "Penyempurnaan tombol Kembali ke Atas."
        ]
    },
    {
        versi: "v1.1",
        tanggal: "15 Okt 2026",
        tipe: "Update Mod",
        gambar: "assets/images/banner.png",
        linkDetail: "efootball-patch.html",
        rincian: [
            "Rilis eFootball 2026 License & Kit Patch v1.0.",
            "Config Ultra Smooth 60 FPS Anti-Lag."
        ]
    }
];

// DATA LATEST CONTENT (3 BLOK KARTU VERTIKAL 9:16 UNTUK VT TIKTOK)
const latestContentData = [
    {
        judul: "Config eFootball Ultra Smooth 60 FPS Anti-Lag!",
        platform: "TikTok VT",
        views: "15.4K Views",
        gambar: "assets/images/banner.png", // Gantilah dengan file gambar/poster VT kamu
        link: "https://www.tiktok.com/@zyreenn"
    },
    {
        judul: "Cara Pasang Patch Lisensi Klub & Kit eFootball 2026",
        platform: "TikTok VT",
        views: "28.1K Views",
        gambar: "assets/images/banner.png",
        link: "https://www.tiktok.com/@zyreenn"
    },
    {
        judul: "Review Grafik Extreme + Game Booster ZYREENN Edition",
        platform: "TikTok VT",
        views: "9.8K Views",
        gambar: "assets/images/banner.png",
        link: "https://www.tiktok.com/@zyreenn"
    }
];

// DATA FAQ (PERTANYAAN POPULER ACCORDION)
const faqData = [
    {
        tanya: "Apakah Patch & Config ZYREENN Aman untuk Akun Utama / Match Online?",
        jawab: "Sangat aman! Seluruh patch dan config yang dirilis ZYREENN hanya memodifikasi aspek visual dan optimasi performa lokal di HP kamu tanpa mengubah sistem server Konami."
    },
    {
        tanya: "Bagaimana Cara Mengatasi Game Keluar Sendiri (Force Close) Setelah Pasang Patch?",
        jawab: "Pastikan versi eFootball kamu sudah paling baru dan spesifikasi HP sesuai. Coba gunakan fitur Cek Kompatibilitas HP untuk memilih versi config yang lebih ringan."
    },
    {
        tanya: "Apakah Seluruh File Modifikasi Ini Gratis?",
        jawab: "Ya! Seluruh patch, config, dan alat pendukung yang ada di website ZYREENN bisa kamu unduh secara gratis."
    }
];
