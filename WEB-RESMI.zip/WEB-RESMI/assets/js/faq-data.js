// DATA FAQ (BEBAS EDIT & TAMBAH PERTANYAAN DI SINI)
const faqData = [
    {
        tanya: "Apakah Patch & Config ZYREENN Aman untuk Akun Utama / Match Online?",
        jawab: "Sangat aman! Seluruh patch dan config yang dirilis ZYREENN hanya memodifikasi aspek visual dan optimasi performa lokal di HP kamu tanpa mengubah sistem server Konami."
    },
    {
        tanya: "Bagaimana Cara Mengatasi Game Keluar Sendiri (Force Close) Setelah Pasang Patch?",
        jawab: "Pastikan versi eFootball kamu sudah paling baru dan spesifikasi HP sesuai. Coba gunakan fitur Cek Kompatibilitas HP untuk memilih versi config yang lebih ringan."
    },
    {
        tanya: "Apakah Seluruh File Modifikasi Ini Gratis?",
        jawab: "Ya! Seluruh patch, config, dan alat pendukung yang ada di website ZYREENN bisa kamu unduh secara gratis."
    },
    {
        tanya: "Bagaimana Cara Memasang Config eFootball di HP Android?",
        jawab: "Unduh file config, ekstrak menggunakan aplikasi ZArchiver, lalu pindahkan file config tersebut ke direktori folder eFootball sesuai dengan petunjuk yang tertera di halaman detail."
    },
    {
        tanya: "Perbedaan eFootball Patch dan Config eFootball Apa?",
        jawab: "eFootball Patch Itu Aplikasi Gamenya sedangkan Config Itu File Nya"
    }
];
