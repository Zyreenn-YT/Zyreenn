const changelogData = [
    {
        versi: "v1.3",
        tanggal: "20 Okt 2026",
        tipe: "Update Fitur",
        gambar: "assets/images/changelog/v1.3-preview.png",
        linkDetail: "cek-kompatibilitas.html",
        rincian: [
            "Rilis halaman Cek Kompatibilitas HP interaktif.",
            "Penambahan LATEST CONTENT dengan format kartu VT 9:16."
        ]
    },
    {
        versi: "v1.2",
        tanggal: "18 Okt 2026",
        tipe: "Update Halaman",
        gambar: "assets/images/changelog/v1.2-preview.png",
        linkDetail: "efootball-patch.html",
        rincian: [
            "Peluncuran halaman khusus eFootball Patch Hub.",
            "Penyempurnaan tombol Kembali ke Atas."
        ]
    },
    {
        versi: "v1.1",
        tanggal: "15 Okt 2026",
        tipe: "Update Mod",
        gambar: "assets/images/changelog/v1.1-preview.png",
        linkDetail: "efootball-patch.html",
        rincian: [
            "Rilis eFootball 2026 License & Kit Patch v1.0.",
            "Config Ultra Smooth 60 FPS Anti-Lag."
        ]
    }
];
