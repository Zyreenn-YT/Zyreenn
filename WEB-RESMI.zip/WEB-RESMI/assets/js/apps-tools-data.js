// DATA APPS & TOOLS PENDUKUNG ZYREENN
const appsToolsData = [
    // BAGIAN 1: APLIKASI PENDUKUNG (3 APLIKASI)
    {
        id: "app-zarchiver",
        tipe: "aplikasi",
        judul: "ZArchiver",
        kategori: "Aplikasi Pendukung",
        gambar: "assets/images/apps/zarchiver.png",
        deskripsiList: [
            "Aplikasi ekstraksi berkas ZIP/RAR terbaik untuk pemasangan patch & config.",
            "Mendukung akses penuh ke direktori folder Android/data dan Android/obb.",
            "Proses ekstraksi aman, cepat, dan mencegah berkas terpotong atau corrupt."
        ],
        linkDownload: "https://sharemods.com/8qn8ky1tc11e/Zarchiver_By.ZyreennYT.zip.html"
    },
    {
        id: "app-mt-manager",
        tipe: "aplikasi",
        judul: "MT Manager",
        kategori: "Aplikasi Pendukung",
        gambar: "assets/images/apps/mt-manager.png",
        deskripsiList: [
            "Pengelola berkas dual-panel andal untuk memindahkan dan mengedit file game.",
            "Memudahkan proses penimpaan (overwrite) file patch dan config eFootball.",
            "Dilengkapi fitur eksekusi skrip dan modifikasi struktur folder secara praktis."
        ],
        linkDownload: "https://sharemods.com/jvh94eg3hsqs/MT-Manager_By.ZyreennYT.zip.html"
    },
    {
        id: "app-shizuku",
        tipe: "aplikasi",
        judul: "Shizuku",
        kategori: "Aplikasi Pendukung",
        gambar: "assets/images/apps/shizuku.png",
        deskripsiList: [
            "Layanan perizinan sistem tanpa root untuk akses folder Android/data & obb.",
            "Membantu file manager menembus batasan sistem keamanan Android 11 ke atas.",
            "Proses konfigurasi praktis menggunakan fitur Wireless Debugging."
        ],
        linkDownload: "https://sharemods.com/1ifexcnx69tw/Shizuku_By.ZyreennYT.zip.html"
    },

    // BAGIAN 2: TOOLS PENDUKUNG (OTOMATIS TERTAMPILKAN SESUAI DATA)
    {
        id: "tool-framex",
        tipe: "tool",
        judul: "FrameX Tool",
        kategori: "Tools Performa",
        gambar: "assets/images/apps/framex.png",
        deskripsiList: [
            "Tools khusus optimasi performa dan pemantau FPS real-time saat match.",
            "Membantu menjaga kestabilan frame rate eFootball agar tetap smooth 60/90 FPS.",
            "Ringan, stabil, dan dirancang khusus mendampingi penggunaan config ZYREENN."
        ],
        linkDownload: "https://sharemods.com/6or24t4s4ko3/FrameX_By.ZyreennYT.zip.html"
    }
];
