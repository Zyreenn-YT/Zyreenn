// DATA CONFIG EFOOTBALL ZYREENN
const configEfootballData = [
    {
        id: "cfg-framerate-v2",
        judul: "Config FrameRate Generation V2",
        subtext: "V6.1.1",
        kategori: "FPS Booster",
        credits: "ZYREENN",
        isSpecial: true,
        gambar: "assets/images/config/config-framerate-generation-v2.png",
        deskripsiList: [
            "Generasi frame rate V2 untuk gameplay ekstra smooth 60/90 FPS.",
            "Mengurangi stuttering dan lag saat match online intensif.",
            "Optimasi khusus untuk patch versi eFootball V6.1.1."
        ],
        linkDetail: "pages/config-framerate-generation-v2.html",
        linkOrder: "https://lynk.id/zyreenn/drkk4jnmk1nm/checkout"
    },
    {
        id: "cfg-premium-max",
        judul: "Config Premium Max",
        subtext: "V6.1.1",
        kategori: "Max Performance",
        credits: "ZYREENN",
        isSpecial: true,
        gambar: "assets/images/config/config-premium-max.png",
        deskripsiList: [
            "Fitur grafik dan performa paling maksimal kelas premium.",
            "Visual tetap tajam dengan stabilitas frame rate tinggi.",
            "Dukungan penuh pembaruan patch eFootball V6.1.1."
        ],
        linkDetail: "pages/config-premium-max.html",
        linkOrder: "https://lynk.id/zyreenn/qx0rz46pzp1o/checkout"
    },
    {
        id: "cfg-extreme-lowest",
        judul: "Config Extreme Lowest",
        subtext: "V6.1.1",
        kategori: "Potato Phone / Anti-Lag",
        credits: "ZYREENN",
        isSpecial: true,
        gambar: "assets/images/config/config-extreme-lowest.png",
        deskripsiList: [
            "Pengaturan rata kiri paling ringan untuk HP spesifikasi rendah.",
            "Penghapusan penonton dan penyeimbangan beban grafik.",
            "Kompatibel penuh dengan versi eFootball V6.1.1."
        ],
        linkDetail: "pages/config-extreme-lowest.html",
        linkOrder: "https://lynk.id/zyreenn/vlwkx1g7nkdl/checkout"
    },
    {
        id: "cfg-custom",
        judul: "Config Custom",
        subtext: "V6.1.1",
        kategori: "Custom Request",
        credits: "ZYREENN",
        isSpecial: true,
        gambar: "assets/images/config/config-custom.png",
        deskripsiList: [
            "Config yang disesuaikan secara khusus sesuai spesifikasi HP kamu.",
            "Bisa request grafik, resolusi, dan pengaturan FPS kustom.",
            "Konsultasi langsung dengan admin ZYREENN untuk V6.1.1."
        ],
        linkDetail: "pages/config-custom.html",
        linkOrder: "https://wa.me/6282291885416?text=Halo%20Admin%20ZYREENN,%20saya%20ingin%20order%20Config%20Custom%20eFootball%20V6.1.1"
    }
];

// DATA TUTORIAL PASANG CONFIG
const configTutorialData = [
    {
        langkah: 1,
        judul: "Order & Unduh File",
        deskripsi: "Pilih config pilihanmu, lakukan order via Lynk.id atau WhatsApp Admin untuk mendapatkan berkas config."
    },
    {
        langkah: 2,
        judul: "Ekstrak Berkas ZIP",
        deskripsi: "Buka aplikasi ZArchiver, cari berkas config yang telah diunduh lalu lakukan ekstrak folder."
    },
    {
        langkah: 3,
        judul: "Pasang ke Folder Game",
        deskripsi: "Salin folder config hasil ekstrak dan tempelkan ke direktori penyimpanan eFootball HP kamu."
    },
    {
        langkah: 4,
        judul: "Buka Game & Mainkan",
        deskripsi: "Jalankan eFootball kamu dan rasakan peningkatan FPS serta performa gameplay yang lebih stabil."
    }
];
