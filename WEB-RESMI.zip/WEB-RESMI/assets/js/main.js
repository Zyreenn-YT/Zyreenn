// Function Pemuat Komponen HTML (Otomatis Deteksi Kedalaman Folder /pages/)
async function loadComponent(elementId, filePath) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const isSubFolder = window.location.pathname.includes("/pages/");
    const finalPath = isSubFolder ? "../" + filePath : filePath;

    try {
        const response = await fetch(finalPath);
        if (response.ok) {
            element.innerHTML = await response.text();
            
            // Penyesuaian otomatis path link & gambar jika dipanggil dari subfolder /pages/
            if (isSubFolder) {
                const links = element.querySelectorAll("a");
                links.forEach(link => {
                    const href = link.getAttribute("href");
                    if (href && !href.startsWith("http") && !href.startsWith("../") && !href.startsWith("#")) {
                        link.setAttribute("href", "../" + href);
                    }
                });

                const images = element.querySelectorAll("img");
                images.forEach(img => {
                    const src = img.getAttribute("src");
                    if (src && !src.startsWith("http") && !src.startsWith("../")) {
                        img.setAttribute("src", "../" + src);
                    }
                });
            }

            if (elementId === "navbar-placeholder") {
                updateActiveNav();
            }
        }
    } catch (error) {
        console.error(`Gagal memuat komponen ${finalPath}:`, error);
    }
}

// Function Menandai Menu Aktif Sesuai Halaman Saat Ini
function updateActiveNav() {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    const navItems = document.querySelectorAll(".nav-menu .nav-item");

    navItems.forEach(item => {
        item.classList.remove("active");
        const href = item.getAttribute("href");

        if (currentPage === "efootball-patch.html" && href && href.includes("efootball-patch.html")) {
            item.classList.add("active");
        } else if ((currentPage === "config-efootball.html" || currentPage.startsWith("config-")) && href && href.includes("config-efootball.html")) {
            item.classList.add("active");
        } else if (currentPage === "cek-kompatibilitas.html" && href && href.includes("cek-kompatibilitas.html")) {
            item.classList.add("active");
        } else if ((currentPage === "index.html" || currentPage === "") && href && href.includes("index.html#beranda")) {
            item.classList.add("active");
        }
    });
}

// Function Render Featured Special Patch 16:9 (eFootball 2027)
function renderFeaturedPatch(data, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !data) return;

    container.innerHTML = `
        <div class="featured-patch-card">
            <div class="featured-img-box">
                <img src="${data.gambar}" alt="${data.judul}" class="featured-img">
            </div>
            <div class="featured-info">
                <div>
                    <span class="badge-red">${data.kategori}</span>
                    <h3>${data.judul}</h3>
                    <div style="margin-bottom: 12px;">
                        <span class="credits-badge special-zyreenn">Credits: ${data.credits}</span>
                    </div>
                    <p>${data.deskripsi}</p>
                </div>
                <a href="${data.linkDetail}" class="btn btn-primary">Info Lengkap & Unduh</a>
            </div>
        </div>
    `;
}

// Function Render Kartu Patch Hub (Gambar 16:9 - Tanpa Logo Mini)
function renderPatchCards(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => {
        const descContent = Array.isArray(item.deskripsiList)
            ? item.deskripsiList.map(desc => `<li>${desc}</li>`).join('')
            : (item.deskripsi ? `<li>${item.deskripsi}</li>` : '');

        return `
            <div class="card">
                <div>
                    ${item.gambar ? `
                    <div class="patch-card-img-box">
                        <img src="${item.gambar}" alt="${item.judul}" class="patch-card-img">
                    </div>` : ''}

                    <div class="card-header-top">
                        <div class="card-tag">${item.kategori}</div>
                    </div>

                    <h3>${item.judul}</h3>

                    <div style="margin-bottom: 12px;">
                        <span class="credits-badge ${item.isSpecial ? 'special-zyreenn' : ''}">
                            Credits: ${item.credits}
                        </span>
                    </div>

                    <ul class="patch-card-list">
                        ${descContent}
                    </ul>
                </div>

                <div class="card-action-buttons">
                    <a href="${item.linkInfo}" target="_blank" class="btn-info">Info Lengkap</a>
                    <a href="${item.linkDownload}" target="_blank" class="btn-download">Download</a>
                </div>
            </div>
        `;
    }).join('');
}

// Function Render Config Cards
function renderConfigCards(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <div class="card">
            <div>
                ${item.gambar ? `
                <div class="patch-card-img-box">
                    <img src="${item.gambar}" alt="${item.judul}" class="patch-card-img" onerror="this.onerror=null; this.src='assets/images/changelog/v1.3-preview.png';">
                </div>` : ''}

                <div class="card-header-top">
                    <div class="card-tag">${item.kategori}</div>
                </div>

                <h3>${item.judul} <span class="subtext-ver">${item.subtext}</span></h3>

                <div style="margin-bottom: 12px;">
                    <span class="credits-badge special-zyreenn">
                        Credits: ${item.credits}
                    </span>
                </div>

                <ul class="patch-card-list">
                    ${item.deskripsiList ? item.deskripsiList.map(desc => `<li>${desc}</li>`).join('') : ''}
                </ul>
            </div>

            <div class="card-action-buttons">
                <a href="${item.linkDetail}" class="btn-info">Info Detail Config</a>
                <a href="${item.linkOrder}" target="_blank" class="btn-download">Order Config</a>
            </div>
        </div>
    `).join('');
}

// Function Render Tutorial Penginstalan Patch
function renderTutorialInstall(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <div class="tutorial-card">
            <span class="step-badge">Langkah ${item.langkah}</span>
            <h3>${item.judul}</h3>
            <p>${item.deskripsi}</p>
        </div>
    `).join('');
}

// Function Render Config Tutorial
function renderConfigTutorial(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <div class="tutorial-card">
            <span class="step-badge">Langkah ${item.langkah}</span>
            <h3>${item.judul}</h3>
            <p>${item.deskripsi}</p>
        </div>
    `).join('');
}

// Function Render Video Tutorial Card (Dinamis & Aman)
function renderVideoTutorial(data, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !data) return;

    // Menambahkan kelas styling hanya saat data tersedia
    container.className = "video-tutorial-card";
    container.innerHTML = `
        <div class="video-tutorial-info">
            <h3>🎬 ${data.judul}</h3>
            <p>${data.deskripsi}</p>
        </div>
        <a href="${data.linkVideo}" target="_blank" rel="noopener noreferrer" class="btn-video">▶ Tonton Tutorial Video</a>
    `;
}

// Function Render Halaman Detail Config Otomatis Berdasarkan Nama File HTML
function renderConfigDetailPage() {
    const container = document.getElementById("configDetailContent");
    if (!container || typeof configEfootballData === 'undefined') return;

    const currentFile = window.location.pathname.split("/").pop();
    const isSubFolder = window.location.pathname.includes("/pages/");
    const targetLink = isSubFolder ? "pages/" + currentFile : currentFile;

    const configItem = configEfootballData.find(item => item.linkDetail === targetLink || item.linkDetail.endsWith(currentFile)) || configEfootballData[0];
    const imagePath = isSubFolder ? "../" + configItem.gambar : configItem.gambar;
    const fallbackPath = isSubFolder ? "../assets/images/changelog/v1.3-preview.png" : "assets/images/changelog/v1.3-preview.png";

    container.innerHTML = `
        <div class="patch-detail-banner-box">
            <img src="${imagePath}" alt="${configItem.judul}" class="patch-detail-banner" onerror="this.onerror=null; this.src='${fallbackPath}';">
        </div>

        <div class="patch-detail-header">
            <div class="patch-detail-meta">
                <span class="badge-red">${configItem.kategori}</span>
                <h1 class="patch-detail-title">${configItem.judul} <span class="subtext-ver">${configItem.subtext}</span></h1>
                <div style="margin-top: 8px;">
                    <span class="credits-badge special-zyreenn">Credits: ${configItem.credits}</span>
                </div>
            </div>
            <a href="${configItem.linkOrder}" target="_blank" class="btn btn-primary btn-download-hero">
                🛒 Order Config Sekarang
            </a>
        </div>

        <div class="patch-detail-body">
            <div class="detail-section-block">
                <h3><span class="border-red"></span> Rincian Fitur Config</h3>
                <ul class="detail-feature-list">
                    ${configItem.deskripsiList.map(point => `<li><strong>Highlight:</strong> ${point}</li>`).join('')}
                </ul>
            </div>

            <div class="detail-section-block" style="margin-top: 30px;">
                <h3><span class="border-red"></span> Catatan & Dukungan System</h3>
                <p class="detail-description">
                    Config ini dioptimasikan khusus untuk eFootball Mobile versi <strong>${configItem.subtext}</strong>. Pastikan kamu mengikuti petunjuk ekstraksi dan penempatan file secara teliti agar performa anti-lag berfungsi secara maksimal.
                </p>
            </div>
        </div>
    `;
}

// Function Render Kartu Game / Unduhan Umum
function renderCards(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <div class="card">
            <div>
                <div class="card-header-top">
                    ${item.logo ? `<img src="${item.logo}" alt="Logo" class="card-mini-logo">` : ''}
                    <div class="card-tag">${item.kategori}</div>
                </div>
                <h3>${item.judul}</h3>
                <p>${item.deskripsi}</p>
            </div>
            <a href="${item.linkDownload}" class="card-btn">Download / Lihat Detail</a>
        </div>
    `).join('');
}

// Function Render Changelog 3 Blok
function renderChangelog(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    const topThreeChangelog = dataList.slice(0, 3);

    container.innerHTML = topThreeChangelog.map(item => `
        <div class="changelog-card-item">
            <div class="changelog-card-body">
                ${item.gambar ? `
                <div class="changelog-img-box">
                    <img src="${item.gambar}" alt="Update ${item.versi}" class="changelog-img">
                </div>` : ''}
                
                <div class="changelog-card-header">
                    <div class="changelog-version-title">
                        ${item.versi} <span class="changelog-badge">${item.tipe}</span>
                    </div>
                    <div class="changelog-date-sub">📅 ${item.tanggal}</div>
                </div>
                
                <ul class="changelog-card-list">
                    ${item.rincian.map(point => `<li>${point}</li>`).join('')}
                </ul>
            </div>
            
            <a href="${item.linkDetail || '#'}" class="card-btn btn-changelog">Lihat Selengkapnya</a>
        </div>
    `).join('');
}

// Function Render Latest Content
function renderLatestContent(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    const topThreeLatest = dataList.slice(0, 3);

    container.innerHTML = topThreeLatest.map(item => `
        <div class="latest-card-item">
            <div class="latest-img-box">
                <img src="${item.gambar}" alt="${item.judul}" class="latest-img">
                <span class="play-badge">▶ ${item.views}</span>
            </div>
            <div class="latest-card-info">
                <span class="card-tag">${item.platform}</span>
                <h3>${item.judul}</h3>
            </div>
            <a href="${item.link}" target="_blank" class="card-btn">Tonton di TikTok</a>
        </div>
    `).join('');
}

// Function Render FAQ
function renderFAQ(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <details class="faq-item">
            <summary>${item.tanya}</summary>
            <div class="faq-answer">${item.jawab}</div>
        </details>
    `).join('');
}

// Hamburger Menu Toggle
function toggleHamburgerMenu() {
    const dropdown = document.getElementById("hamburgerDropdown");
    if (dropdown) {
        dropdown.classList.toggle("active");
    }
}

// Close Hamburger saat klik di luar
window.addEventListener("click", (e) => {
    const dropdown = document.getElementById("hamburgerDropdown");
    const button = document.querySelector(".hamburger-btn");
    if (dropdown && button && !dropdown.contains(e.target) && !button.contains(e.target)) {
        dropdown.classList.remove("active");
    }
});

// Fitur Pencarian Beranda
function filterKonten() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    
    if (typeof unduhanPopulerData !== 'undefined') {
        const filteredUnduhan = unduhanPopulerData.filter(item => 
            item.judul.toLowerCase().includes(input) || 
            item.kategori.toLowerCase().includes(input)
        );
        renderCards(filteredUnduhan, "unduhanPopulerContainer");
    }
}

// Inisialisasi Pemuatan Komponen & Data pada main.js
document.addEventListener("DOMContentLoaded", async () => {
    await loadComponent("navbar-placeholder", "components/navbar.html");
    await loadComponent("hero-placeholder", "components/hero.html");
    await loadComponent("changelog-placeholder", "components/changelog.html");
    await loadComponent("latest-content-placeholder", "components/latest-content.html");
    await loadComponent("unduhan-populer-placeholder", "components/unduhan-populer.html");
    await loadComponent("info-footer-placeholder", "components/info-footer.html");

    // Render Beranda
    if (typeof unduhanPopulerData !== 'undefined') renderCards(unduhanPopulerData, "unduhanPopulerContainer");
    if (typeof changelogData !== 'undefined') renderChangelog(changelogData, "changelogContainer");
    if (typeof latestContentData !== 'undefined') renderLatestContent(latestContentData, "latestContentContainer");
    if (typeof faqData !== 'undefined') renderFAQ(faqData, "faqContainer");
    
    // Render eFootball Patch Hub & Tutorial
    if (typeof featuredPatchData !== 'undefined') renderFeaturedPatch(featuredPatchData, "featuredPatchContainer");
    if (typeof eFootballPatchData !== 'undefined') renderPatchCards(eFootballPatchData, "patchGridContainer");
    if (typeof tutorialInstallData !== 'undefined') renderTutorialInstall(tutorialInstallData, "tutorialContainer");
    if (typeof patchVideoTutorialData !== 'undefined') renderVideoTutorial(patchVideoTutorialData, "patchVideoTutorialContainer");

    // Render Config eFootball Hub & Tutorial
    if (typeof configEfootballData !== 'undefined') renderConfigCards(configEfootballData, "configGridContainer");
    if (typeof configTutorialData !== 'undefined') renderConfigTutorial(configTutorialData, "configTutorialContainer");
    if (typeof configVideoTutorialData !== 'undefined') renderVideoTutorial(configVideoTutorialData, "videoTutorialContainer");
    
    // Render Halaman Detail Config
    renderConfigDetailPage();
});

// Function Populate Dropdown Chipset Berdasarkan Brand yang Dipilih
function populateChipsetOptions(selectedBrand = "") {
    const chipsetSelect = document.getElementById("chipsetSelect");
    if (!chipsetSelect || typeof chipsetRawData === 'undefined') return;

    chipsetSelect.innerHTML = '<option value="">-- Pilih Chipset --</option>';

    chipsetRawData.forEach(brandData => {
        if (!selectedBrand || brandData.brand === selectedBrand) {
            Object.keys(brandData.tiers).forEach(tierKey => {
                brandData.tiers[tierKey].forEach(chipModel => {
                    const option = document.createElement("option");
                    option.value = chipModel;
                    option.textContent = `${chipModel} (${tierKey.replace('_', '-')})`;
                    chipsetSelect.appendChild(option);
                });
            });
        }
    });
}

// Function Event ketika Brand Dropdown Berubah
function onBrandChange() {
    const brandSelect = document.getElementById("brandSelect");
    const searchInput = document.getElementById("chipsetSearchInput");
    if (searchInput) searchInput.value = ""; // Clear input pencarian
    
    populateChipsetOptions(brandSelect ? brandSelect.value : "");
}

// Function Event ketika Input Search Diketik
function onSearchInput() {
    const searchInput = document.getElementById("chipsetSearchInput");
    const brandSelect = document.getElementById("brandSelect");
    const keyword = searchInput.value.toLowerCase().trim();

    if (keyword.length > 0) {
        if (brandSelect) brandSelect.value = ""; // Reset brand select
        populateChipsetOptions(""); // Tampilkan seluruh chipset yang cocok
    }
}

// Function Evaluasi Performa & Cari Tier Chipset
function findChipsetTier(chipsetModel) {
    if (typeof chipsetRawData === 'undefined') return null;

    let result = null;
    chipsetRawData.forEach(brandData => {
        Object.keys(brandData.tiers).forEach(tierKey => {
            brandData.tiers[tierKey].forEach(model => {
                if (model.toLowerCase() === chipsetModel.toLowerCase()) {
                    result = {
                        brand: brandData.brand,
                        model: model,
                        tier: tierKey.replace('_', '-')
                    };
                }
            });
        });
    });

    // Jika pencarian parsial jika tidak persis sama
    if (!result) {
        chipsetRawData.forEach(brandData => {
            Object.keys(brandData.tiers).forEach(tierKey => {
                brandData.tiers[tierKey].forEach(model => {
                    if (model.toLowerCase().includes(chipsetModel.toLowerCase()) && !result) {
                        result = {
                            brand: brandData.brand,
                            model: model,
                            tier: tierKey.replace('_', '-')
                        };
                    }
                });
            });
        });
    }

    return result;
}

// Function Proses Cek Kompatibilitas dengan Tampilan Spesifik & Tombol Ringkas di Kanan
function prosesCekKompatibilitas() {
    const chipsetSelect = document.getElementById("chipsetSelect");
    const searchInput = document.getElementById("chipsetSearchInput");
    const resultWrapper = document.getElementById("compatibilityResultWrapper");

    let query = searchInput && searchInput.value.trim() ? searchInput.value.trim() : (chipsetSelect ? chipsetSelect.value : "");

    if (!query) {
        alert("Silakan pilih chipset dari dropdown atau ketik nama chipset HP kamu!");
        return;
    }

    const foundData = findChipsetTier(query);

    if (!foundData) {
        resultWrapper.style.display = "block";
        resultWrapper.innerHTML = `
            <div class="result-card-box" style="text-align: center;">
                <h3 style="color: var(--brand-red); font-size: 22px;">Chipset Tidak Ditemukan</h3>
                <p style="color: var(--text-gray); margin-top: 10px;">
                    Maaf, data chipset "<strong>${query}</strong>" belum terdaftar. Kamu bisa memilih Config Extreme Lowest demi keamanan performa HP kamu.
                </p>
                <div class="result-action-buttons" style="justify-content: center; margin-top: 20px;">
                    <a href="config-efootball.html" class="btn-result-hub">📁 Ke Halaman Config eFootball Hub</a>
                </div>
            </div>
        `;
        resultWrapper.scrollIntoView({ behavior: 'smooth' });
        return;
    }

    const tierKey = foundData.tier.replace('-', '_');
    const recConfig = configRecommendationMap[tierKey] || configRecommendationMap["MID_LOW"];

    // Format item spesifik (Config -> Preset -> Tombol Kanan)
    const itemsHtml = recConfig.items.map(item => `
        <div class="rec-item-card">
            <div class="rec-item-info">
                <div class="rec-item-title">
                    🔥 <strong>${item.nama}</strong> <span class="subtext-ver">${item.subtext}</span>
                </div>
                <div class="rec-item-preset">
                    ⚙️ Preset Disarankan: <span>${item.preset}</span>
                </div>
            </div>
            <a href="${item.linkDetail}" class="btn-small-order">Detail & Order</a>
        </div>
    `).join('');

    resultWrapper.style.display = "block";
    resultWrapper.innerHTML = `
        <div class="result-card-box">
            <div class="result-card-header">
                <div>
                    <span class="card-tag">${foundData.brand}</span>
                    <h3 class="result-chipset-name">${foundData.model}</h3>
                </div>
                <span class="badge-red">${recConfig.tierBadge}</span>
            </div>

            <p class="detail-description">${recConfig.deskripsi}</p>

            <div style="margin-top: 20px; margin-bottom: 20px;">
                <label style="font-size: 13px; color: var(--brand-red); font-weight: 700; text-transform: uppercase; display: block; margin-bottom: 12px;">
                    REKOMENDASI CONFIG & PRESET:
                </label>
                <div class="rec-items-wrapper">
                    ${itemsHtml}
                </div>
            </div>

            <div class="result-action-buttons">
                <a href="config-efootball.html" class="btn-result-hub" style="width: 100%; text-align: center;">
                    🚀 Lihat Semua Config di Halaman Config eFootball Hub
                </a>
            </div>
        </div>
    `;

    resultWrapper.scrollIntoView({ behavior: 'smooth' });
}

// Function Render Apps & Tools Berdasarkan Tipe
function renderAppsAndToolsByTipe(dataList) {
    if (!Array.isArray(dataList)) return;

    const appContainer = document.getElementById("aplikasiGridContainer");
    const toolContainer = document.getElementById("toolsGridContainer");

    const aplikasiData = dataList.filter(item => item.tipe === "aplikasi");
    const toolData = dataList.filter(item => item.tipe === "tool");

    if (appContainer) {
        appContainer.innerHTML = generateCardListHtml(aplikasiData);
    }

    if (toolContainer) {
        toolContainer.innerHTML = generateCardListHtml(toolData);
    }
}

// Helper Function Template Kartu
function generateCardListHtml(dataList) {
    if (!dataList || dataList.length === 0) {
        return `<p style="color: var(--text-gray); grid-column: 1 / -1;">Belum ada tools tambahan.</p>`;
    }

    return dataList.map(item => `
        <div class="card">
            <div>
                ${item.gambar ? `
                <div class="patch-card-img-box">
                    <img src="${item.gambar}" alt="${item.judul}" class="patch-card-img" onerror="this.onerror=null; this.src='assets/images/changelog/v1.3-preview.png';">
                </div>` : ''}

                <div class="card-header-top">
                    <div class="card-tag">${item.kategori}</div>
                </div>

                <h3>${item.judul}</h3>

                <ul class="patch-card-list">
                    ${item.deskripsiList ? item.deskripsiList.map(desc => `<li>${desc}</li>`).join('') : ''}
                </ul>
            </div>

            <div class="card-action-buttons">
                <a href="${item.linkDownload}" target="_blank" rel="noopener noreferrer" class="btn-download" style="width: 100%;">
                    Unduh Aplikasi
                </a>
            </div>
        </div>
    `).join('');
}

// Inisialisasi awal saat DOM dimuat
document.addEventListener("DOMContentLoaded", () => {
    if (typeof appsToolsData !== 'undefined') {
        renderAppsAndToolsByTipe(appsToolsData);
    }
});

// Function Menandai Menu Navbar Aktif Otomatis
function updateActiveNavLink() {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    const navLinks = document.querySelectorAll(".nav-item, .hamburger-dropdown a");

    navLinks.forEach(link => {
        const linkHref = link.getAttribute("href");
        if (linkHref === currentPage) {
            link.classList.add("active");
        } else {
            link.classList.remove("active");
        }
    });
}

// Function Load Component HTML (Async/Await)
async function loadComponent(elementId, filePath) {
    const element = document.getElementById(elementId);
    if (!element) return;
    try {
        const response = await fetch(filePath);
        if (response.ok) {
            element.innerHTML = await response.text();
        }
    } catch (error) {
        console.error(`Gagal memuat komponen ${filePath}:`, error);
    }
}

// Function Menandai Menu Navbar Aktif Otomatis
function highlightActiveNav() {
    let currentPath = window.location.pathname.split("/").pop();
    if (!currentPath || currentPath === "") {
        currentPath = "index.html";
    }

    const navLinks = document.querySelectorAll(".nav-item, .hamburger-dropdown a");

    navLinks.forEach(link => {
        const href = link.getAttribute("href");
        if (href === currentPath) {
            link.classList.add("active");
        } else {
            link.classList.remove("active");
        }
    });
}

// Inisialisasi Pemuatan Komponen & Fitur
document.addEventListener("DOMContentLoaded", async () => {
    // 1. Wajib gunakan AWAIT agar navbar selesai di-render ke DOM
    await loadComponent("navbar-placeholder", "components/navbar.html");
    await loadComponent("info-footer-placeholder", "components/info-footer.html");

    // 2. Jalankan penanda menu aktif tepat setelah navbar siap
    highlightActiveNav();

    // 3. Render fitur khusus halaman
    if (typeof appsToolsData !== 'undefined') {
        renderAppsAndToolsByTipe(appsToolsData);
    }
    if (typeof chipsetRawData !== 'undefined') {
        populateChipsetOptions("");
    }
});

// Function Render Kartu Kategori Game
function renderGameCategoryCards(dataList, containerId) {
    const container = document.getElementById(containerId);
    if (!container || !Array.isArray(dataList)) return;

    container.innerHTML = dataList.map(item => `
        <div class="card">
            <div>
                ${item.gambar ? `
                <div class="patch-card-img-box">
                    <img src="${item.gambar}" alt="${item.judul}" class="patch-card-img" onerror="this.onerror=null; this.src='assets/images/changelog/v1.3-preview.png';">
                </div>` : ''}

                <div class="card-header-top">
                    <span class="card-tag">${item.kategori}</span>
                    <span class="credits-badge ${item.isAvailable ? 'special-zyreenn' : ''}">${item.statusBadge}</span>
                </div>

                <h3>${item.judul}</h3>

                <ul class="patch-card-list">
                    ${item.deskripsiList ? item.deskripsiList.map(desc => `<li>${desc}</li>`).join('') : ''}
                </ul>
            </div>

            <div class="card-action-buttons">
                ${item.isAvailable ? `
                    <a href="${item.link}" class="btn-download" style="width: 100%; text-align: center;">
                        ${item.btnText}
                    </a>
                ` : `
                    <button class="btn-info" style="width: 100%; opacity: 0.6; cursor: not-allowed;" disabled>
                        ${item.btnText}
                    </button>
                `}
            </div>
        </div>
    `).join('');
}

// Panggil pada event DOMContentLoaded
document.addEventListener("DOMContentLoaded", async () => {
    // ...pemanggilan komponen navbar/footer yang sudah ada...

    if (typeof gameCategoryData !== 'undefined') {
        renderGameCategoryCards(gameCategoryData, "gameCategoryContainer");
    }
});
