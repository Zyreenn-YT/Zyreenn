// DATA TUTORIAL CARA PASANG PATCH
const tutorialInstallData = [
    {
        langkah: 1,
        judul: "Unduh File Patch",
        deskripsi: "Pilih patch yang kamu inginkan di halaman ini, lalu klik tombol Download untuk mengunduh file patch."
    },
    {
        langkah: 2,
        judul: "Ekstrak File ZIP / RAR",
        deskripsi: "Buka aplikasi ZArchiver, cari file patch di folder Download, lalu pilih Ekstrak Di Sini."
    },
    {
        langkah: 3,
        judul: "Pindahkan Folder Patch",
        deskripsi: "Salin atau potong folder hasil ekstrak, lalu tempel ke direktori folder eFootball sesuai petunjuk."
    },
    {
        langkah: 4,
        judul: "Buka Game & Selesai",
        deskripsi: "Jalankan game eFootball kamu, periksa pembaruan grafik/kit jersey baru, dan selamat bermain!"
    }
];
