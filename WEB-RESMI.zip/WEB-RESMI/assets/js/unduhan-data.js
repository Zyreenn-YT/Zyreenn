const unduhanPopulerData = [
    {
        kategori: "eFootball Patch",
        judul: "eFootball 2026 License & Kit Patch v1.0",
        deskripsi: "Membuka seluruh lisensi klub, Jersey original 2026, dan logo liga resmi.",
        linkDownload: "efootball-patch.html",
        logo: "assets/images/icons/logo-mini-efootball.png"
    },
    {
        kategori: "Config eFootball",
        judul: "Config Ultra Smooth 60 FPS (Anti-Lag)",
        deskripsi: "Optimasi grafik untuk HP spesifikasi menengah ke bawah agar lancar tanpa lag.",
        linkDownload: "cek-kompatibilitas.html",
        logo: "assets/images/icons/logo-mini-config.png"
    },
    {
        kategori: "Game Android",
        judul: "Game Booster Pro ZYREENN Edition",
        deskripsi: "Aplikasi pembersih RAM dan penstabil jaringan ping saat bermain game online.",
        linkDownload: "#",
        logo: "assets/images/icons/logo-mini-booster.png"
    },
    {
        kategori: "Emulator",
        judul: "PPSSPP Gold Mod ZYREENN Theme",
        deskripsi: "Emulator PSP dengan tema kostum Merah ZYREENN & settingan lancar.",
        linkDownload: "#",
        logo: "assets/images/icons/logo-mini-ppsspp.png"
    }
];
