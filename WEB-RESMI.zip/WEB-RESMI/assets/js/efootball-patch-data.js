// DATA EFOOTBALL 2027 PATCH (FEATURED SPECIAL EDITION)
const featuredPatchData = {
    id: "ef-2027-special",
    judul: "EFOOTBALL 2027 PATCH (SPECIAL EDITION)",
    kategori: "Special Patch",
    credits: "ZYREENN",
    isSpecial: true,
    gambar: "assets/images/changelog/v1.3-preview.png",
    deskripsi: "Patch eksklusif buatan ZYREENN dengan perombakan total grafik, kit jersey terbaru 2027, scoreboard kustom, dan optimasi performa terbaik.",
    linkDetail: "pages/efootball-2027-detail.html"
};

// DATA EFOOTBALL PATCH LAINNYA (2 BARIS x 2 BLOK - TANPA PROPERTI LOGO MINI)
const eFootballPatchData = [
    {
        id: "ef-ucl-patch",
        judul: "EFOOTBALL PATCH UCL SEASON",
        kategori: "UEFA Champions League",
        credits: "idsphone",
        isSpecial: false,
        gambar: "assets/images/changelog/v1.2-preview.png",
        deskripsiList: [
            "Full lisensi klub & papan skor khas UEFA Champions League.",
            "Tampilan atmosfer stadion malam hari yang lebih realistis.",
            "Jersey edisi spesial Eropa 2026/2027 lengkap."
        ],
        linkInfo: "https://www.idsphone.com/2026/10/ucl-patch-efootball-mobile-v1111-season.html?m=1",
        linkDownload: "https://link.idsphone.com/p/ucl-patch-efootball-mobile-v1111-season.html"
    },
    {
        id: "ef-epl-patch",
        judul: "EFOOTBALL PATCH EPL",
        kategori: "Premier League",
        credits: "idsphone",
        isSpecial: false,
        gambar: "assets/images/changelog/v1.1-preview.png",
        deskripsiList: [
            "Lisensi penuh seluruh 20 tim Liga Utama Inggris (EPL).",
            "Sistem papan skor & grafik ala siaran TV Premier League.",
            "Update font nomor punggung resmi klub Liga Inggris."
        ],
        linkInfo: "https://www.idsphone.com/2026/10/ea-epl-patch-efootball-mobile-v1111-by.html?m=1",
        linkDownload: "https://link.idsphone.com/p/ea-epl-patch-efootball-mobile-v1111-by.html"
    },
    {
        id: "ef-original-patch",
        judul: "EFOOTBALL PATCH ORIGINAL THEME",
        kategori: "Original Theme",
        credits: "idsphone",
        isSpecial: false,
        gambar: "assets/images/changelog/v1.3-preview.png",
        deskripsiList: [
            "Tema klasik original eFootball v11.1.1 yang sangat stabil.",
            "Ringan dan tidak membebani performa chipset HP menengah.",
            "Perbaikan bug tekstur rumput & bayangan pemain."
        ],
        linkInfo: "https://www.idsphone.com/2026/10/original-theme-patch-efootball-mobile_01249064592.html?m=1",
        linkDownload: "https://www.idsphone.com/p/safelink.html?url=aHR0cHM6Ly93d3cubWVkaWFmaXJlLmNvbS9maWxlL2VraG15aGRvM2E0Njl5aC9PUklfVEhFTUFfRUZQMjdfSURTUEhPTkVfVjExLjEuMS56aXAvZmlsZQ%3D%3D&m=1"
    },
    {
        id: "ef-worldcup-patch",
        judul: "EFOOTBALL PATCH WORLD CUP",
        kategori: "National Teams",
        credits: "idsphone",
        isSpecial: false,
        gambar: "assets/images/changelog/v1.2-preview.png",
        deskripsiList: [
            "Pembaruan jersey & lisensi tim nasional seluruh dunia.",
            "Papan skor & bola resmi turnamen internasional.",
            "Optimasi animasi masuk lapangan untuk laga timnas."
        ],
        linkInfo: "https://www.idsphone.com/2026/10/ucl-patch-efootball-mobile-v1111-season.html?m=1",
        linkDownload: "https://link.idsphone.com/p/ucl-patch-efootball-mobile-v1111-season.html"
    }
];
