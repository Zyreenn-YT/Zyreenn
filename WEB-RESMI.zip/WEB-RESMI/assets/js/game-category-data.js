// DATA KATEGORI GAME ZYREENN
const gameCategoryData = [
    {
        id: "game-efootball",
        judul: "eFootball Mobile",
        kategori: "Sepak Bola",
        statusBadge: "AKTIF",
        gambar: "assets/images/games/efootball-banner.png",
        deskripsiList: [
            "Pusat Patch eFootball visual jernih & pembaruan jersey/logo.",
            "Kumpulan Config Anti-Lag, Frame Rate Generation, & Grafik Max.",
            "Dilengkapi fitur Cek Kompatibilitas Chipset HP otomatis."
        ],
        link: "config-efootball.html",
        btnText: "🚀 Masuk ke Hub eFootball",
        isAvailable: true
    },
    {
        id: "game-eafc",
        judul: "EA SPORTS FC Mobile",
        kategori: "Sepak Bola",
        statusBadge: "SEGERA HADIR",
        gambar: "assets/images/games/eafc-banner.png",
        deskripsiList: [
            "Config optimasi FPS dan penstabilan responsivitas kontrol.",
            "Tweak grafik kustom untuk performa HP kelas menengah & entry-level.",
            "Panduan serta tutorial pemasangan modul pendukung."
        ],
        link: "#",
        btnText: "⏳ Segera Hadir",
        isAvailable: false
    },
    {
        id: "game-mlbb",
        judul: "Mobile Legends: Bang Bang",
        kategori: "MOBA",
        statusBadge: "SEGERA HADIR",
        gambar: "assets/images/games/mlbb-banner.png",
        deskripsiList: [
            "Modul optimasi jaringan dan penstabilan ping.",
            "Buka opsi Ultra Graphics & 120 FPS secara aman.",
            "Tools utilitas pembantu performa match."
        ],
        link: "#",
        btnText: "⏳ Segera Hadir",
        isAvailable: false
    }
];
