// DATA CHIPSET BERDASARKAN KATEGORI DAN TIER
const chipsetRawData = [
    {
        brand: "Qualcomm Snapdragon",
        tiers: {
            HIGH: [
                "Snapdragon 8 Elite Gen 6", "Snapdragon 8 Elite Gen 5", "Snapdragon 8 Elite",
                "Snapdragon 8 Gen 5", "Snapdragon 8 Gen 4", "Snapdragon 8s Gen 4",
                "Snapdragon 8 Gen 3", "Snapdragon 8s Gen 3", "Snapdragon 8 Gen 2",
                "Snapdragon 7+ Gen 3", "Snapdragon 8+ Gen 1", "Snapdragon 7+ Gen 2",
                "Snapdragon 8 Elite Extreme Gen 6"
            ],
            MID: [
                "Snapdragon 888+", "Snapdragon 888", "Snapdragon 7s Gen 4", "Snapdragon 7 Gen 4",
                "Snapdragon 6 Gen 5", "Snapdragon 7s Gen 3", "Snapdragon 865+", "Snapdragon 870",
                "Snapdragon 7 Gen 3", "Snapdragon 782G", "Snapdragon 865", "Snapdragon 6 Gen 4",
                "Snapdragon 778G+", "Snapdragon 780G", "Snapdragon 778G", "Snapdragon 7 Gen 1",
                "Snapdragon 7s Gen 2", "Snapdragon 6s Gen 4", "Snapdragon 6 Gen 1"
            ],
            LOW: [
                "Snapdragon 6s Gen 3", "Snapdragon 4 Gen 5", "Snapdragon 4 Gen 4", "Snapdragon 4 Gen 2",
                "Snapdragon 695", "Snapdragon 750G", "Snapdragon 480+", "Snapdragon 4s Gen 2",
                "Snapdragon 4 Gen 1", "Snapdragon 765G", "Snapdragon 690", "Snapdragon 720G",
                "Snapdragon 732G", "Snapdragon 480", "Snapdragon 678", "Snapdragon 6s 4G Gen 2",
                "Snapdragon 685", "Snapdragon 680", "Snapdragon 6s 4G Gen 1 / 662", "Snapdragon 460"
            ]
        }
    },
    {
        brand: "MediaTek Dimensity dan Helio",
        tiers: {
            HIGH: [
                "Dimensity 9600 Pro", "Dimensity 9600M", "Dimensity 9500", "Dimensity 9500M",
                "Dimensity 9500s", "Dimensity 9400+", "Dimensity 9400", "Dimensity 9400e",
                "Dimensity 9300+", "Dimensity 9300", "Dimensity 9200+", "Dimensity 9200",
                "Dimensity 8550", "Dimensity 9000+", "Dimensity 9000", "Dimensity 8500",
                "Dimensity 8450", "Dimensity 8400", "Dimensity 8350"
            ],
            MID: [
                "Dimensity 8250", "Dimensity 8200", "Dimensity 8100", "Dimensity 8020 / 1100",
                "Dimensity 8000", "Dimensity 7450X", "Dimensity 7350", "Dimensity 7050",
                "Dimensity 7400", "Dimensity 7400X", "Dimensity 1000+", "Dimensity 7030 / 1050",
                "Dimensity 7360", "Dimensity 7300X", "Dimensity 7300", "Dimensity 7100",
                "Dimensity 7050 / 1080", "Dimensity 920", "Dimensity 900", "Dimensity 7020 / 930",
                "Dimensity 820"
            ],
            LOW: [
                "Dimensity 6400", "Dimensity 6360", "Dimensity 6300", "Dimensity 720",
                "Dimensity 6080 / 810", "Dimensity 800U", "Dimensity 6100+", "Helio G200",
                "Helio G100", "Dimensity 6020 / 700", "Helio G90+", "Helio G99",
                "Dimensity 6100e", "Helio G96", "Dimensity 800", "Helio G95", "Helio G92",
                "Helio G88", "Helio G70", "Helio G80", "Helio G81", "Helio G91", "Helio G36",
                "Helio G37", "Helio G50", "Helio G35", "Helio G25"
            ]
        }
    },
    {
        brand: "Samsung Exynos",
        tiers: {
            HIGH: ["Exynos 2600", "Exynos 2500", "Exynos 2400", "Exynos 2400e", "Exynos 2200"],
            MID: ["Exynos 1680", "Exynos 1580", "Exynos 1480", "Exynos 1380", "Exynos 1610", "Exynos 1330", "Exynos 1280"],
            LOW: ["Exynos 2100", "Exynos 990", "Exynos 850"]
        }
    },
    {
        brand: "UNISOC",
        tiers: {
            HIGH: [],
            MID: ["UNISOC T9300", "UNISOC T7300", "UNISOC T8300", "UNISOC T9100 / T820", "UNISOC T8200 / T765", "UNISOC T8100 / T760"],
            LOW: [
                "UNISOC T7280 / T620", "UNISOC T618", "UNISOC T7255 / T616", "UNISOC T7250 / T615",
                "UNISOC T7225 / T612", "UNISOC T700", "UNISOC T610", "UNISOC T7200 / T606",
                "UNISOC T7100 / T603 / SC9863A"
            ]
        }
    },
    {
        brand: "Google Tensor",
        tiers: {
            HIGH: ["Tensor G6", "Tensor G5", "Tensor G4", "Tensor G3"],
            MID: ["Tensor G2", "Tensor generasi pertama"],
            LOW: []
        }
    }
];

// PEMETAAN REKOMENDASI CONFIG & PRESET SPESIFIK
const configRecommendationMap = {
    HIGH: {
        tierBadge: "HIGH",
        deskripsi: "Chipset HP kamu tergolong Android High-End. Semua Config dan Preset dapat berjalan dengan sangat lancar pada performa tertinggi.",
        items: [
            { nama: "Config FrameRate Generation V2", subtext: "V6.1.1", preset: "HIGH, MID, LOW", linkDetail: "pages/config-framerate-generation-v2.html" },
            { nama: "Config Premium Max", subtext: "V6.1.1", preset: "HIGH, MID, LOW", linkDetail: "pages/config-premium-max.html" },
            { nama: "Config Extreme Lowest", subtext: "V6.1.1", preset: "NO PRESET", linkDetail: "pages/config-extreme-lowest.html" },
            { nama: "Config Custom", subtext: "V6.1.1", preset: "BEBAS", linkDetail: "pages/config-custom.html" }
        ]
    },
    MID: {
        tierBadge: "MID",
        deskripsi: "Chipset HP kamu berada di kelas Android Mid. Disarankan menggunakan Preset Mid atau Low untuk menjaga kestabilan FPS dan suhu HP.",
        items: [
            { nama: "Config FrameRate Generation V2", subtext: "V6.1.1", preset: "MID, LOW", linkDetail: "pages/config-framerate-generation-v2.html" },
            { nama: "Config Premium Max", subtext: "V6.1.1", preset: "MID, LOW", linkDetail: "pages/config-premium-max.html" },
            { nama: "Config Extreme Lowest", subtext: "V6.1.1", preset: "NO PRESET", linkDetail: "pages/config-extreme-lowest.html" },
            { nama: "Config Custom", subtext: "V6.1.1", preset: "BEBAS", linkDetail: "pages/config-custom.html" }
        ]
    },
    LOW: {
        tierBadge: "LOW",
        deskripsi: "Chipset HP kamu berada di kelas Android Low. Rekomendasi utama adalah Config Extreme Lowest agar gameplay bebas lag.",
        items: [
            { nama: "Config Extreme Lowest (Utama)", subtext: "V6.1.1", preset: "NO PRESET", linkDetail: "pages/config-extreme-lowest.html" },
            { nama: "Alternatif: Semua Config Lainnya", subtext: "V6.1.1", preset: "Wajib Preset LOW", linkDetail: "config-efootball.html" }
        ]
    }
};
