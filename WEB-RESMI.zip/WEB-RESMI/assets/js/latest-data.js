const latestContentData = [
    {
        judul: "Config eFootball Ultra Smooth 60 FPS Anti-Lag!",
        platform: "TikTok VT",
        views: "15.4K Views",
        gambar: "https://vt.tiktok.com/ZSgS3npYh/",
        link: "https://vt.tiktok.com/ZSgS39fVa/"
    },
    {
        judul: "Cara Pasang Patch Lisensi Klub & Kit eFootball 2026",
        platform: "TikTok VT",
        views: "28.1K Views",
        gambar: "assets/images/latest/vt-patch-2026.png",
        link: "https://vt.tiktok.com/ZSgS3g6W5/"
    },
    {
        judul: "Review Grafik Extreme + Game Booster ZYREENN Edition",
        platform: "TikTok VT",
        views: "9.8K Views",
        gambar: "assets/images/latest/vt-booster-review.png",
        link: "https://vt.tiktok.com/ZSgS3npYh/"
    }
];
