(() => {
  const vendorSelect = document.querySelector('#vendor-filter');
  const searchInput = document.querySelector('#chipset-search');
  const results = document.querySelector('#chipset-results');
  const output = document.querySelector('#compat-output');
  const count = document.querySelector('#chipset-count');
  const help = document.querySelector('#search-help');
  if (!vendorSelect || !searchInput || !results || !output) return;

  const configs = [
    'Config FrameRate Generation',
    'Config Premium Max',
    'Config Extreme Lowest',
    'Config Custom'
  ];
  let chipsets = [];
  let selected = null;

  const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tierClass = tier => tier.toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '');
  const tierLabel = tier => tier;
  const presetChips = presets => presets.map((p, i) => `<span class="preset-chip ${i===0?'active':''}">${esc(p)}</span>`).join('');

  function fillVendors() {
    const vendors = [...new Set(chipsets.map(c => c.vendor))].sort();
    vendors.forEach(vendor => {
      const option = document.createElement('option');
      option.value = vendor;
      option.textContent = vendor;
      vendorSelect.appendChild(option);
    });
    count.textContent = chipsets.length;
  }

  function filtered() {
    const vendor = vendorSelect.value;
    const query = searchInput.value.trim().toLowerCase();
    return chipsets.filter(c => (vendor === 'all' || c.vendor === vendor) &&
      (!query || c.name.toLowerCase().includes(query) || c.vendor.toLowerCase().includes(query) || c.tier.toLowerCase().includes(query)))
      .slice(0, 80);
  }

  function renderResults() {
    const list = filtered();
    results.innerHTML = '';
    if (!list.length) {
      results.innerHTML = '<div class="no-results">Chipset tidak ditemukan. Periksa ejaan atau pilih kategori lain.</div>';
      help.textContent = 'Tidak ada hasil yang cocok dengan pencarian.';
      return;
    }
    help.textContent = `${list.length} hasil ditampilkan${filtered().length >= 80 ? ' (maksimal 80 hasil)' : ''}. Pilih chipset untuk melihat rekomendasi.`;
    list.forEach(c => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'chipset-option';
      button.setAttribute('role','option');
      button.setAttribute('aria-selected', String(selected && selected.name === c.name && selected.vendor === c.vendor));
      button.innerHTML = `<span><strong>${esc(c.name)}</strong><small>${esc(c.vendor)}</small></span><span class="tier-pill ${tierClass(c.tier)}">${esc(c.tier)}</span>`;
      button.addEventListener('click', () => {
        selected = c;
        renderResults();
        renderRecommendation(c);
      });
      results.appendChild(button);
    });
  }

  function renderRecommendation(c) {
    const tier = c.tier;
    let cards = '';
    if (tier === 'HIGH') {
      cards = configs.map((name, i) => `<article class="recommend-card ${i===0?'primary':''}"><div class="recommend-top"><h4>${esc(name)}</h4><span class="recommend-order">${i===0?'UTAMA':`ALTERNATIF ${i}`}</span></div><div class="preset-row">${presetChips(['High','Mid','Low'])}</div></article>`).join('');
    } else if (tier === 'MID-HIGH') {
      cards = configs.map((name, i) => `<article class="recommend-card ${i===0?'primary':''}"><div class="recommend-top"><h4>${esc(name)}</h4><span class="recommend-order">${i===0?'UTAMA':`ALTERNATIF ${i}`}</span></div><div class="preset-row">${presetChips(['Mid','Low'])}</div></article>`).join('');
    } else {
      cards = `<article class="recommend-card primary"><div class="recommend-top"><h4>Config Extreme Lowest</h4><span class="recommend-order">UTAMA</span></div><p class="preset-note">Tidak ada pilihan preset — file hanya menyediakan satu preset.</p></article>
      <div class="alternative-label">Alternatif · semua Config dengan Preset Low</div>
      ${configs.map((name, i) => `<article class="recommend-card"><div class="recommend-top"><h4>${esc(name)}</h4><span class="recommend-order">ALTERNATIF ${i+1}</span></div><div class="preset-row">${presetChips(['Low'])}</div></article>`).join('')}`;
    }
    output.innerHTML = `<div class="selected-chipset"><div class="chip-cpu-icon" aria-hidden="true">▦</div><div><h3>${esc(c.name)}</h3><p>${esc(c.vendor)} · Kategori ${esc(tierLabel(tier))}</p></div></div><p class="recommend-title">REKOMENDASI CONFIG</p><div class="recommend-list">${cards}</div><p class="preset-note">Urutan dan preset mengikuti aturan kategori yang kamu berikan. Hasil ini adalah panduan awal, bukan jaminan performa pada semua model perangkat.</p>`;
  }

  vendorSelect.addEventListener('change', renderResults);
  searchInput.addEventListener('input', renderResults);

  fetch('data/chipsets.json')
    .then(response => { if (!response.ok) throw new Error('Gagal memuat database'); return response.json(); })
    .then(data => {
      chipsets = data;
      fillVendors();
      renderResults();
    })
    .catch(() => {
      count.textContent = '—';
      results.innerHTML = '<div class="no-results">Database chipset belum dapat dimuat. Jalankan website melalui hosting web atau server lokal agar file JSON dapat diakses.</div>';
      help.textContent = 'Database belum tersedia.';
    });
})();