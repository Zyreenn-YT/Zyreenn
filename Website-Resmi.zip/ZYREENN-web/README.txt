ZYREENN WEBSITE — MAJOR REDESIGN

Isi folder ini adalah website statis HTML/CSS/JavaScript yang bisa di-deploy ke Netlify.

CARA DEPLOY
1. Ekstrak ZIP.
2. Buka folder ZYREENN-web.
3. Upload ISI folder ZYREENN-web ke Netlify (index.html harus berada di root deploy).

HALAMAN
- index.html: Beranda
- patch.html: eFootball Patch
- store.html: Config Store
- apps.html: Aplikasi Pendukung
- 404.html: Halaman tidak ditemukan

Aset gambar yang sudah ada dipertahankan. Tautan eksternal berasal dari website sumber yang diberikan dan tidak diverifikasi ketersediaannya.

- compatibility.html: Compatibility Checker chipset Android dan rekomendasi Config.
- data/chipsets.json: Database chipset dan kategori performa.
- assets/js/compatibility.js: Logika pencarian dan rekomendasi.
- assets/css/compatibility.css: Gaya halaman Compatibility Checker.

Catatan: halaman Compatibility Checker menggunakan fetch untuk membaca data/chipsets.json. Gunakan hosting statis seperti Netlify atau server lokal, bukan membuka file HTML langsung via file://.
